import sys
import random


def remove_empty(list_str):
    ret_list = []
    for elem in list_str:
        if elem != '':
            ret_list.append(elem)
    return ret_list


# [horizon, n_task, n_resource, processing_times, resource_capacities, resource_allocations_task,
#  resource_allocations_resource, resource_allocations_quantity, task_before, task_after]
def get_info_sm(filename):
    info = []
    with open(filename, "r") as in_file:
        line = in_file.readline()
        while line.strip().split(" ")[0] != "jobs":
            line = in_file.readline()
        n_task = int(line.strip().split(" ")[-1])
        info.append(int(in_file.readline().strip().split(" ")[-1]))
        info.append(n_task)
        in_file.readline()
        info.append(int(remove_empty(in_file.readline().strip().split(" "))[-2]))
        for i in range(9):
            in_file.readline()
        task_before = []
        task_after = []
        line = in_file.readline()
        while line[0] != '*':
            for i in range(int(remove_empty(line.strip().split(" "))[2])):
                task_before.append(int(remove_empty(line.strip().split(" "))[0]))
                task_after.append(int(remove_empty(line.strip().split(" "))[3 + i]))
            line = in_file.readline()
        for i in range(3):
            in_file.readline()
        processing_times = []
        resource_allocation_task = []
        resource_allocation_resource = []
        resource_allocation_quantity = []
        line = in_file.readline()
        while line[0] != '*':
            processing_times.append(int(remove_empty(line.strip().split(" "))[2]))
            for i in range(info[2]):
                if int(remove_empty(line.strip().split(" "))[3 + i]) > 0:
                    resource_allocation_task.append(int(remove_empty(line.strip().split(" "))[0]))
                    resource_allocation_resource.append(i + 1)
                    resource_allocation_quantity.append(int(remove_empty(line.strip().split(" "))[3 + i]))
            line = in_file.readline()
        info.append(processing_times)
        in_file.readline()
        in_file.readline()
        line = in_file.readline()
        resource_capacities = []
        for i in range(info[2]):
            resource_capacities.append(int(remove_empty(line.strip().split(" "))[i]))
        info.append(resource_capacities)
        info.append(resource_allocation_task)
        info.append(resource_allocation_resource)
        info.append(resource_allocation_quantity)
        info.append(task_before)
        info.append(task_after)
    return info


def gen_instance(info, hour):
    horizon, n_tasks, n_resources, processing_times, resource_capacity, task_allocations, resource_allocations,\
        resource_allocations_consomption, task_before, task_after = info

    cal_followed = []
    if hour:
        for i in range(n_tasks):
            r = random.random()
            if (processing_times[i] == 0) or (0 <= r <= 0.10):
                cal_followed.append(0)
            elif 0.10 <= r <= 0.25:
                cal_followed.append(1)
            elif 0.25 <= r <= 0.40:
                cal_followed.append(2)
            elif 0.40 <= r <= 0.60:
                cal_followed.append(3)
            elif 0.60 <= r <= 0.80:
                cal_followed.append(4)
            else:
                cal_followed.append(5)
    else:
        for i in range(n_tasks):
            r = random.random()
            if (processing_times[i] == 0) or (0 <= r <= 0.20):
                cal_followed.append(0)
            elif 0.20 <= r <= 0.40:
                cal_followed.append(1)
            elif 0.40 <= r <= 0.60:
                cal_followed.append(2)
            elif 0.60 <= r <= 0.80:
                cal_followed.append(3)
            else:
                cal_followed.append(4)

    init_time_decal = random.randint(0, 6)
    day_zero = init_time_decal

    if hour:
        horizon *= 5
    else:
        horizon *= 2
    print("horizon = {};".format(horizon))
    if over:
        print("weight_makespan = 0;")
        print("weight_overtime_cost = 1;")
    else:
        print("weight_makespan = 1;")
        print("weight_overtime_cost = 0;")

    print()

    if hour:
        print("hour = true;")
    else:
        print("hour = false;")
    
    print("forbid_overtime = true;")

    print()

    print("n_tasks = {};".format(n_tasks))
    print("processing_times = {};".format(processing_times))
    earliest_starting_times = [-1 for _ in range(n_tasks)]
    print("tasks_est = {};".format(earliest_starting_times))
    print("tasks_lst = {};".format(earliest_starting_times))
    print("tasks_ect = {};".format(earliest_starting_times))
    print("tasks_lct = {};".format(earliest_starting_times))

    print()

    print("n_resources = {};".format(n_resources))
    print("resources_capacity = {};".format(resource_capacity))
    print("over_time_costs = {};".format([random.randint(50, 200) for _ in range(n_resources)]))

    print()

    n_allocations = len(resource_allocations)
    print("n_consomptions = {};".format(n_allocations))
    print("task_that_consumes = {};".format(task_allocations))
    print("consomption_amount = {};".format(resource_allocations_consomption))
    print("resource_consumed = {};".format(resource_allocations))

    num_precedences = len(task_before)
    print("n_precedences = {};".format(num_precedences))
    print("task_before = {};".format(task_before))
    print("task_after = {};".format(task_after))

    if hour:
        print("n_calendars = 5;")
        print("n_regular_hours_per_day = array1d(0..n_calendars, [1, 8, 8, 8, 8, 8]);")
        print("n_overtime_hours_per_day = array1d(0..n_calendars, [0, 4, 4, 4, 4, 4]);")
    else:
        print("n_calendars = 4;")
        print("n_regular_hours_per_day = array1d(0..n_calendars, [1, 8, 8, 8, 8]);")
        print("n_overtime_hours_per_day = array1d(0..n_calendars, [0, 4, 4, 4, 4]);")

    for i in range(n_tasks):
        cal_followed[i] -= 1
    print("followed_calendar = array1d(tasks, {});".format(cal_followed))
    to_print = ""
    if day_zero < 6:
        weekend = [5 - day_zero, 6 - day_zero]
    else:
        weekend = [0, 6]

    holidays = []
    if hour:
        for i in range((horizon + 1) // 24):
            if random.random() < 0.05:
                holidays.append(i)
    else:
        for i in range(horizon + 1):
            if random.random() < 0.05:
                holidays.append(i)

    def is_weekend_or_holiday(day):
        return (day % 7 in weekend) or (day in holidays)

    if hour:
        # Calendar without weekends or holidays
        for i in range(horizon + 1):
            if (not is_weekend_or_holiday(i // 24)) and (8 <= i % 24 < 20):
                if i % 24 < 16:
                    to_print += "1"
                else:
                    to_print += "2"
            else:
                to_print += "0"
            to_print += ", "

        # Calendar without holidays
        for i in range(horizon + 1):
            if (i // 24 not in holidays) and (8 <= i % 24 < 20):
                if i % 24 < 16:
                    to_print += "1"
                else:
                    to_print += "2"
            else:
                to_print += "0"
            to_print += ", "

        # Calendar without weekends, holidays or overtime
        for i in range(horizon + 1):
            if (not is_weekend_or_holiday(i // 24)) and (8 <= i % 24 < 16):
                to_print += "1"
            else:
                to_print += "0"
            to_print += ", "

        # Calendar without holidays or overtime
        for i in range(horizon + 1):
            if (i // 24 not in holidays) and (8 <= i % 24 < 16):
                to_print += "1"
            else:
                to_print += "0"
            to_print += ", "

        # Calendar with weekends and holidays as overtime
        for i in range(horizon + 1):
            if 8 <= i % 24 < 20:
                if is_weekend_or_holiday(i // 24):
                    to_print += "2"
                else:
                    if i % 24 < 16:
                        to_print += "1"
                    else:
                        to_print += "2"
            else:
                to_print += "0"
            if i < horizon:
                to_print += ", "
        print("calendars = array2d(0..4, 0..{}, [".format(horizon) + to_print + "]);")
    else:
        # Calendar without weekends or holidays
        for i in range(horizon + 1):
            if not is_weekend_or_holiday(i):
                to_print += "1, "
            else:
                to_print += "0, "

        # Calendar without holidays
        for i in range(horizon + 1):
            if i not in holidays:
                to_print += "1, "
            else:
                to_print += "0, "

        # Calendar without weekends, holidays or overtime
        for i in range(horizon + 1):
            if not is_weekend_or_holiday(i):
                to_print += "1, "
            else:
                to_print += "0, "

        # Calendar without holidays or overtime
        for i in range(horizon + 1):
            if i not in holidays:
                to_print += "1"
            else:
                to_print += "0"
            if i < horizon:
                to_print += ", "
        print("calendars = array2d(0..3, 0..{}, [".format(horizon) + to_print + "]);")


def convert(filename):
    info = get_info_sm(filename)

    with open("./Day/" + filename.split("/")[-1].split(".")[0] + "_day_makespan.dzn", "w") as out_file:
        sys.stdout = out_file
        gen_instance(info, False)

    with open("./Hour/" + filename.split("/")[-1].split(".")[0] + "_hour_makespan.dzn", "w") as out_file:
        sys.stdout = out_file
        gen_instance(info, True)

    # For overtime optimisation, we should first optimise the makespan and then modify the files.


if __name__ == "__main__":
    convert(sys.argv[1])
    # convert("psplib/j302_6.sm")

